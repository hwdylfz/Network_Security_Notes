模数分解：
    n, p, q, e, d, phi(fn)
    知道其中的一个，求剩下的
数据提取：
    pem，pcap，nc（交互式应用）
