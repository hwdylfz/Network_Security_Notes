交互模式：

./yafu-x64.exe

factor(N)

=====================================

从文件读取：

./yafu-x64.exe "factor(@)" -batchfile pcat.txt
