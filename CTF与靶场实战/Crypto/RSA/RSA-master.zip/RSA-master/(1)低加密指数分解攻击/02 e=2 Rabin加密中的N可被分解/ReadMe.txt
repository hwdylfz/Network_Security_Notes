Rabin加密中的N可被分解
适用情况：e==2

Rabin加密是RSA的衍生算法，e==2是Rabin加密典型特征，可以百度或阅读 https://en.wikipedia.org/wiki/Rabin_cryptosystem 以了解到详细的说明，
这里只关注解密方法。一般先通过其他方法分解得到p，q，然后解密。