题目给出rsa公钥和密文文件。

使用RSACtfTool根据公钥计算私钥

![深度截图_选择区域_20190705161842](img/clip_image002.png)

使用openssl根据公钥和私钥解开密文文件

![深度截图_选择区域_20190705162156](img/clip_image003.png)

打开输出的明文文件txt即可得到flag