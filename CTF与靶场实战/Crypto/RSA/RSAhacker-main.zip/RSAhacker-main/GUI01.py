import os
import time

def show():
    os.system("clear")
    os.system("figlet RSAHacker")
    print()
    print("Author   : Zhang Jiayuan, Li Weidong, Wang Zheng")
    print("Yuque    :https://www.yuque.com/u2401365")
    print("Gitee    :https://gitee.com/j0kerz")
    print("GitHub   :https://github.com/Hipste2")
    print()

def HackWork():
    print("[                    ] 0% ")
    time.sleep(1)
    print("[=====               ] 25%")
    time.sleep(0.5)
    print("[==========          ] 50%")
    time.sleep(0.5)
    print("[===============     ] 75%")
    time.sleep(0.5)
    print("[====================] 100%")
    time.sleep(0.5)

def End():
    time.sleep(2)
    os.system("clear")
    os.system("figlet RSAHacker")