### jherron

* Initial drop

### S0lll0s

* Added --explode option to prevent placing the payload in long runs of opcodes that do not take an argument 
  as this can lead to exposure of the payload through tools like ```strings```