s = int(input("请输入N的值求亲密数"))
y = int(s/2)
array=[1 for i in range(s)]
if s >= 350:
    for i in range(2,y):
        j = 2*i 
        while(j<s):
            array[j]+=i
            j+=i
    for i in range(s):
        if array[i]>i and array[i]<=s and array[array[i]]==i:
            print (i,array[i])

                
else:
    print ('input error')


