# -*- coding:utf-8 -*-
print("字符转换acsii--1.1启动")
print('请输入待转换的ASCII码，每组的ASCII码用空格分开:')

a = input()
q = input("是否输入完成 Y OR NO:")

if q == 'y':

    num = [int(n)for n in a.split()]
    tmp =''
    for i in num:
        tmp =tmp+chr(i)
    print(tmp)
else:
    print("没有完成 再见")

