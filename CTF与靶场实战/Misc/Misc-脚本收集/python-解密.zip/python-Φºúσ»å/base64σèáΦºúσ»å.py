import base64 
print("加密请输入：en \n解密请输入: de")
s = input("请选择加密OR解密:")
if s =='en':
    y = input("请输入需要加密的字符串:")
    str2=base64.b64encode(y.encode('utf-8'))
    
    print(str2)
elif s =='de':

    q = input("请输入需要解密的字符串:")
    str1 = base64.b64decode(q.encode('utf-8'))
    print(str1)

    
else:
    print("输入错误告辞！！！")    